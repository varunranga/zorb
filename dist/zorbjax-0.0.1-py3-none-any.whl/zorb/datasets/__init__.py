from .BostonHousing import BostonHousing
from .CIFAR10 import CIFAR10
from .CIFAR100 import CIFAR100
from .Iris import Iris
from .MNIST import MNIST
from .Sinc import Sinc
from .TwoSpirals import TwoSpirals
from .XOR import XOR